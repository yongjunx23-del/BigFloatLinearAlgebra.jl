# Changelog

All notable changes to this project are documented here. The format is based on
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.1.0] - unreleased

### Added

- `AbstractBFLABackend`, `NativeBackend`, and `GenericBackend` backend types.
- `capabilities(backend)` audit hook returning a fixed capability tuple.
- Ownership-safe storage API: `owned_zeros`, `owned_similar`, `owned_copy`,
  `copy_owned!`, `zero_owned!`, and `fill_owned!`.
- BLAS Level 1: `scal!`, `axpy!`, `axpby!`, `dot`, and `norminf`.
- BLAS Level 2: `gemv!`, `trsv!`, and `syr!`.
- BLAS Level 3: `gemm!`, `syrk!`, `trmm!`, and `trsm!`.
- `mirror_triangle!` for symmetric triangle completion.
- Lower-triangular Cholesky factorization and solve:
  `try_cholesky!`, `cholesky!`, `cholesky`, `ldiv!`, `solve!`, and `solve`.
- `NativeBackend` kernels extracted and generalized from the SDPX legacy
  BigFloat dense kernels (see `THIRD_PARTY_NOTICES.md`).
- Immutable `KernelConfig` and precision-scoped `BFLAWorkspace` storage.
- Blocked and explicitly threaded Native GEMM, SYRK, TRSM, and Cholesky paths.
- Solver-relevant symmetric kernels: `gemmt!`, `symv!`, and `syr2k!`.
- Symmetric-indefinite Bunch-Kaufman LDLT factors, solves, inertia, pivot
  structure, and diagnostics.
- Column-pivoted rank-revealing QR with explicit permutation, numerical rank,
  R diagonal, Q/Q-transpose application, and vector/multi-RHS solve.
- Caller-owned residual computation and normwise backward-error measurement
  for ordinary and transposed vector/multi-RHS systems.
- Explicit higher-precision residual computation with p/q precision diagnostics
  and no ambient precision dependence or automatic policy decisions.
- One-step iterative refinement through the factor's recorded backend, with
  caller-owned residual/correction storage and before/after error diagnostics.
- `convert_owned!` for explicit reusable conversion into caller-owned
  destination precision while preserving destination MPFR object identity.
- Dense square partial-pivoting LU with explicit row-swap/permutation
  diagnostics and vector/multi-RHS solves for both backends.
- `GenericBackend` reference implementations built on `LinearAlgebra` generic
  methods.

### Reference

The Native backend derives from SDPX `src/kernels/bigfloat.jl` as found at the
time of extraction. No SDPX source is vendored; attribution is retained in
`THIRD_PARTY_NOTICES.md`.

### Performance

The `NativeBackend` GEMM and SYRK kernels hoist `TransposeOp` flags to
compile-time `Val` parameters, eliminating the O(n^2) heap allocation previously
caused by runtime `Val` dispatch boxing mutable MPFR scratch. GEMM/SYRK now
allocate a constant number of bytes (matching the SDPX legacy owned kernels),
and Cholesky, TRSM, and `dot` are at allocation parity or better than the
frozen legacy path.

### Changed

- Enforce a uniform-precision invariant across every element of every
  `BigFloat` array at the public API boundary; intra-array and cross-operand
  mismatches now fail closed with `PrecisionMismatch`.
- `capabilities(backend)` now reports backend-specific `cholesky_triangles`
  (`(Lower,)` for Native, `(Lower, Upper)` for Generic) using the public
  `Triangle` enum.
- `norminf` on an empty `BigFloat` array fails closed instead of inheriting
  ambient `setprecision`.
- CI runs tests with an explicit `--threads` flag and asserts the real
  `Threads.nthreads()` against the matrix axis.
- Test harness includes `test/test_utils.jl` once, removing method-overwrite
  warnings.
- `owned_copy`/`owned_similar` now require a uniform source precision by
  default; explicit cross-precision conversion is only via `precision_bits`.
- `ldiv!`/`solve!` re-verify factor storage precision against the recorded
  factor precision instead of trusting factorization-time metadata.
- Factorization status is now a machine-readable `FactorStatus`
  (`:success`, `:not_positive_definite`, `:nonfinite`, `:singular`,
  `:pivot_failure`) with an optional failure position, replacing integer
  sentinels.
- Factor permutation, pivot, and block-structure accessors return defensive
  copies, and all BFLA factor types support `size(F, dimension)`.
- Cholesky, LDLT, QR, and LU factor-use boundaries reject non-finite
  authoritative factor storage and right-hand sides before mutation, and reject
  non-finite results instead of reporting a successful solve.
- LDLT now treats only the lower triangle as authoritative, rebuilding the
  inactive upper triangle before symmetric pivoting so stale or poisoned upper
  data cannot affect the factorization.
- Ownership conversion now distinguishes overlapping array storage from
  cross-array sharing of mutable MPFR objects: `convert_owned!` rejects both,
  while `copy_owned!` safely repairs the latter with fresh destination objects.
- Native LDLT pivot decisions now use explicit factor-precision scratch for
  absolute values and Bunch-Kaufman thresholds, independent of ambient
  `setprecision`.
- `gemmt!` and `syr2k!` now validate every transformed outer and contraction
  dimension before entering a kernel, leaving the destination unchanged on
  failure.
- LDLT mirrored entries now use ownership-preserving MPFR copies, including
  after 1x1 and 2x2 pivots, trailing updates, and symmetric permutations.
- In-place LDLT now rejects pre-aliased authoritative-lower `BigFloat` entries
  before mutation, so every successful factor satisfies the independent-storage
  invariant without weakening lower-triangle authority.
- LDLT solve, QR Q application, and QR solve now dispatch explicitly through
  the backend stored in the factor and reject unsupported backends before
  mutation.
- `fill_owned!` now validates the fill value and the complete destination
  precision before mutation, making precision failures atomic.
- `mirror_triangle!` now validates complete matrix precision before copying,
  so mixed-precision failures leave both triangles unchanged.
- `KernelConfig` now rejects non-positive thread counts and negative block
  sizes; the unused `ldlt_block` field was removed rather than exposing an
  inert tuning control.
- `BFLAWorkspace` is now documented as caller-managed scratch, and ineffective
  `workspace=` kernel keywords were removed instead of being silently ignored.

### Final review hardening

- Complete the Bunch-Kaufman pivot decision with the intermediate keep-current
  1x1 test, preventing a nonsingular matrix from being rejected after selecting
  an avoidably singular 2x2 pivot block.
- Configurable Level-3/Cholesky dispatchers preserve the standard
  `UnsupportedOperation` contract for unregistered backends, and LDLT now
  resolves backend support before rebuilding the inactive triangle.

### API and diagnostics freeze

- In-place Cholesky now rejects shared mutable `BigFloat` storage within the
  selected authoritative triangle before any numerical mutation. Inactive
  triangle sharing remains irrelevant, and allocating Cholesky repairs aliased
  source storage through an ownership-safe deep copy.
- Cholesky, LDLT, RRQR, and LU now share a public factor metadata protocol,
  including `factor_triangle` and `factor_failure_position`, so consumers do
  not need concrete factor fields.
- Backend capabilities now state explicitly that QR is column-pivoted and
  rank-revealing rather than unpivoted.
- RRQR rank selection now supports explicit absolute and relative tolerances,
  records the largest input-column norm and effective threshold, and exposes
  scale-aware `numerical_rank` re-evaluation plus defensive rank metadata.
  The legacy `tol` spelling remains an absolute-only compatibility mode.
- Public factor diagnostics now expose Cholesky diagonal range/ratio, LDLT
  minimum 1x1 pivot and 2x2 determinant/normalized quality, and RRQR accepted
  and rejected diagonal facts. These APIs validate live precision and finite
  storage and do not make solver-policy decisions.
- RRQR auxiliary metadata now participates in every factor-use precision and
  finite check, including `refine_once!` validation before residual or
  correction storage can be modified.
- Add correctness-gated production-cycle, standalone, and explicit
  block/thread benchmark runners. They report cold/warm timing, IQR,
  allocations, RSS, precision, size, threads, block size, and source commit;
  mutable operands are rebuilt outside standalone timed regions and fixtures
  use exact rational values rather than Float64 staging.
- Harden the opt-in frozen SDPX Legacy A/B so every reported operation passes
  bitwise parity and mutable setup is excluded from operation timing.
- Restore the frozen row/column access path for untransposed Native GEMM while
  preserving its buffered MPFR reduction order and public validation contract.
- Restore row-segment access in unblocked lower Native Cholesky without
  changing authoritative-triangle, failure-position, or MPFR trajectory rules.
- Benchmark output now reports effective thread counts and block calibration
  skips configurations whose thread count is ignored by blocked or Cholesky
  dispatch.
- Cholesky can explicitly reuse a precision-matched, worker-local workspace
  buffer for its authoritative-triangle ownership scan. The workspace stores
  only object identifiers, preserves the exact numerical path, and is rejected
  before matrix mutation on precision or worker mismatch.
